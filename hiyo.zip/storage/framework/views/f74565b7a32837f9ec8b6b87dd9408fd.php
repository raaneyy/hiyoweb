<!DOCTYPE html>
<html lang="id" class="h-full bg-[#FDF9F1]">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verifikasi Keamanan - Digital Diary</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Playfair+Display:ital,wght@0,400..700;1,400..700&display=swap" rel="stylesheet">
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        .font-serif-diary {
            font-family: 'Cormorant Garamond', 'Playfair Display', Georgia, serif;
        }
        /* Remove number spinner arrows */
        input[type=number]::-webkit-inner-spin-button, 
        input[type=number]::-webkit-outer-spin-button { 
            -webkit-appearance: none; 
            margin: 0; 
        }
        input[type=number] {
            -moz-appearance: textfield;
        }
    </style>
</head>
<body class="min-h-screen bg-[#FDF9F1] flex flex-col items-center justify-between p-4 sm:p-8 selection:bg-[#EADBCE]" 
      x-data="{ activeTab: '<?php echo e(old('login_type', $activeTab ?? 'reader')); ?>' }">

    <!-- Top Navigation -->
    <header class="w-full max-w-4xl flex items-center justify-between py-2">
        <a href="<?php echo e(route('landing')); ?>" class="text-xs text-stone-500 hover:text-stone-800 uppercase tracking-widest font-semibold flex items-center gap-1">
            &larr; Kembali ke Landing Page
        </a>

        <!-- Tab Switcher (Pembaca vs Admin) -->
        <div class="bg-[#EBE3D3] p-1 rounded-lg flex items-center gap-1 text-xs">
            <button type="button" 
                    @click="activeTab = 'reader'"
                    :class="activeTab === 'reader' ? 'bg-white text-stone-900 shadow-2xs font-semibold' : 'text-stone-600 hover:text-stone-900'"
                    class="px-3 py-1.5 rounded-md transition-all">
                Reader
            </button>
            <button type="button" 
                    @click="activeTab = 'admin'"
                    :class="activeTab === 'admin' ? 'bg-white text-stone-900 shadow-2xs font-semibold' : 'text-stone-600 hover:text-stone-900'"
                    class="px-3 py-1.5 rounded-md transition-all">
                Make a Diary
            </button>
        </div>
    </header>

    <!-- MAIN BINDER NOTEBOOK CARD CONTAINER -->
    <div class="my-auto w-full max-w-4xl px-2">
        
        <!-- Flash Alert Messages -->
        <?php if(session('error')): ?>
            <div class="mb-4 bg-rose-50 border border-rose-200 text-rose-800 px-4 py-3 rounded-lg text-sm flex items-center justify-between shadow-2xs">
                <span><?php echo e(session('error')); ?></span>
                <button onclick="this.parentElement.remove()" class="text-rose-600 font-bold">&times;</button>
            </div>
        <?php endif; ?>

        <?php if(session('admin_error')): ?>
            <div class="mb-4 bg-rose-50 border border-rose-200 text-rose-800 px-4 py-3 rounded-lg text-sm flex items-center justify-between shadow-2xs">
                <span><?php echo e(session('admin_error')); ?></span>
                <button onclick="this.parentElement.remove()" class="text-rose-600 font-bold">&times;</button>
            </div>
        <?php endif; ?>

        <!-- Outer Frame -->
        <div class="bg-[#EBE3D3]/60 p-3 sm:p-6 rounded-2xl border border-[#DFD6C4] shadow-lg">
            
            <!-- BINDER CARD DESIGN (MATCHING USER REFERENCE IMAGE 2) -->
            <div class="bg-[#FFFDF9] rounded-xl overflow-hidden border border-[#E5DAC6] shadow-sm flex flex-col md:flex-row relative min-h-[460px]">
                
                <!-- Left Black Spine Binder Strip -->
                <div class="w-12 md:w-16 bg-[#231F20] flex flex-row md:flex-col items-center justify-around py-4 md:py-8 shrink-0 z-10 shadow-inner">
                    <div class="w-3 h-3 rounded-full bg-[#141213] border border-stone-700 shadow-xs"></div>
                    <div class="w-3 h-3 rounded-full bg-[#141213] border border-stone-700 shadow-xs"></div>
                    <div class="w-3 h-3 rounded-full bg-[#141213] border border-stone-700 shadow-xs"></div>
                    <div class="w-3 h-3 rounded-full bg-[#141213] border border-stone-700 shadow-xs"></div>
                    <div class="w-3 h-3 rounded-full bg-[#141213] border border-stone-700 shadow-xs"></div>
                    <div class="w-3 h-3 rounded-full bg-[#141213] border border-stone-700 shadow-xs"></div>
                </div>

                <!-- Main Inner Content Area -->
                <div class="flex-grow p-6 sm:p-10 md:p-12 flex flex-col justify-between bg-[#FFFDF9]">

                    <!-- TAB 1: PEMBACA DIARY (VERIFIKASI TANGGAL) -->
                    <div x-show="activeTab === 'reader'" x-transition class="flex flex-col justify-between flex-grow">
                        <div>
                            <!-- Header Title -->
                            <div class="text-center mb-6 sm:mb-8">
                                <h1 class="font-serif-diary italic text-3xl sm:text-4xl text-stone-900 font-medium tracking-wide">
                                    Verifikasi
                                </h1>
                                <p class="text-[11px] sm:text-xs font-semibold uppercase tracking-widest text-stone-500 mt-3 max-w-xl mx-auto leading-relaxed">
                                    MASUKKAN TANGGAL KITA PACARAN (KALAU GA TAU, GAUSAH BUKA WHAHAHA)
                                </p>
                            </div>

                            <!-- Verification Form -->
                            <form action="<?php echo e(route('login.reader')); ?>" method="POST" class="space-y-6 max-w-2xl mx-auto">
                                <?php echo csrf_field(); ?>

                                <!-- 3 Inputs (HARI, BULAN, TAHUN) -->
                                <div class="grid grid-cols-3 gap-3 sm:gap-6 bg-[#F3EFE6] p-4 sm:p-6 rounded-lg border border-[#E7DEC8]">
                                    
                                    <!-- HARI -->
                                    <div class="bg-white rounded-md p-3 sm:p-4 border border-[#ECE3D2] shadow-2xs text-left">
                                        <label for="hari" class="block text-[10px] sm:text-xs font-semibold uppercase tracking-wider text-stone-400">
                                            HARI
                                        </label>
                                        <input type="number" name="hari" id="hari" min="1" max="31" placeholder="14" value="<?php echo e(old('hari')); ?>" required
                                               class="w-full text-center font-serif-diary italic text-stone-800 text-xl sm:text-3xl font-medium focus:outline-none bg-transparent mt-1">
                                    </div>

                                    <!-- BULAN -->
                                    <div class="bg-white rounded-md p-3 sm:p-4 border border-[#ECE3D2] shadow-2xs text-left">
                                        <label for="bulan" class="block text-[10px] sm:text-xs font-semibold uppercase tracking-wider text-stone-400">
                                            BULAN
                                        </label>
                                        <input type="number" name="bulan" id="bulan" min="1" max="12" placeholder="03" value="<?php echo e(old('bulan')); ?>" required
                                               class="w-full text-center font-serif-diary italic text-stone-800 text-xl sm:text-3xl font-medium focus:outline-none bg-transparent mt-1">
                                    </div>

                                    <!-- TAHUN -->
                                    <div class="bg-white rounded-md p-3 sm:p-4 border border-[#ECE3D2] shadow-2xs text-left">
                                        <label for="tahun" class="block text-[10px] sm:text-xs font-semibold uppercase tracking-wider text-stone-400">
                                            TAHUN
                                        </label>
                                        <input type="number" name="tahun" id="tahun" placeholder="2023" value="<?php echo e(old('tahun')); ?>" required
                                               class="w-full text-center font-serif-diary italic text-stone-800 text-xl sm:text-3xl font-medium focus:outline-none bg-transparent mt-1">
                                    </div>

                                </div>

                                <!-- VERIFIKASI BUTTON -->
                                <div>
                                    <button type="submit" 
                                            class="w-full bg-stone-950 hover:bg-black text-white font-sans font-semibold text-xs sm:text-sm uppercase tracking-[0.2em] py-4 rounded-md shadow-sm transition-all active:scale-[0.99]">
                                        VERIFIKASI &rarr;
                                    </button>
                                </div>
                            </form>
                        </div>

                        <!-- Page Marker Footer -->
                        <div class="mt-6 text-left text-xs font-serif-diary italic text-stone-400">
                        </div>
                    </div>

                    <!-- TAB 2: ADMIN LOGIN (PASSWORD KELOLA DIARY) -->
                    <div x-show="activeTab === 'admin'" x-transition class="flex flex-col justify-between flex-grow" x-cloak>
                        <div>
                            <!-- Header Title -->
                            <div class="text-center mb-6 sm:mb-8">
                                <h1 class="font-serif-diary italic text-3xl sm:text-4xl text-stone-900 font-medium tracking-wide">
                                    Akses Diary
                                </h1>
                                <p class="text-[11px] sm:text-xs font-semibold uppercase tracking-widest text-stone-500 mt-3 max-w-xl mx-auto">
                                    MASUKKAN PASSWORD
                                </p>
                            </div>

                            <!-- Admin Form -->
                            <form action="<?php echo e(route('login.admin')); ?>" method="POST" class="space-y-6 max-w-md mx-auto">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="login_type" value="admin">

                                <div class="bg-[#F3EFE6] p-6 rounded-lg border border-[#E7DEC8] space-y-4">
                                    <label for="admin_password" class="block text-xs font-semibold uppercase tracking-wider text-stone-600">
                                        Password
                                    </label>
                                    <input type="password" name="password" id="admin_password" placeholder="Masukkan password" required
                                           class="w-full bg-white border border-[#ECE3D2] rounded-md px-4 py-3 text-sm text-stone-800 focus:outline-none focus:ring-2 focus:ring-stone-400 shadow-2xs font-sans">
                                </div>

                                <div>
                                    <button type="submit" 
                                            class="w-full bg-stone-950 hover:bg-black text-white font-sans font-semibold text-xs sm:text-sm uppercase tracking-[0.2em] py-4 rounded-md shadow-sm transition-all active:scale-[0.99]">
                                        MASUK &rarr;
                                    </button>
                                </div>
                            </form>
                        </div>

                        <div class="mt-6 text-left text-xs font-serif-diary italic text-stone-400">
                        </div>
                    </div>

                </div>

            </div>

        </div>
    </div>

</body>
</html>
<?php /**PATH C:\laragon\www\hiyoweb\resources\views/auth/login.blade.php ENDPATH**/ ?>