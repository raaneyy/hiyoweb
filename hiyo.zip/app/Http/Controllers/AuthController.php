<?php

namespace App\Http\Controllers;

use App\Models\Diary;
use App\Models\Setting;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function landing()
    {
        if (session('is_reader_verified') || session('is_admin')) {
            $diary = Diary::first();
            if ($diary) {
                return redirect()->route('diary.show', $diary->id);
            }
        }

        return view('landing');
    }

    public function showLogin(Request $request)
    {
        $activeTab = $request->query('tab', 'reader');
        $clue = Setting::get('reader_clue', 'AWAL MARET');

        return view('auth.login', compact('activeTab', 'clue'));
    }

    public function verifyReader(Request $request)
    {
        $request->validate([
            'hari' => 'required|numeric|min:1|max:31',
            'bulan' => 'required|numeric|min:1|max:12',
            'tahun' => 'required|numeric',
        ]);

        $hari = (int) $request->hari;
        $bulan = (int) $request->bulan;
        $tahun = (int) $request->tahun;

        // Ambil validasi tanggal dari database (tabel settings)
        $dbDay = (int) Setting::get('reader_day', 18);
        $dbMonth = (int) Setting::get('reader_month', 3);
        $dbYear = (int) Setting::get('reader_year', 2026);

        // Dukung jika tanggal disimpan dalam format date YYYY-MM-DD
        $dbDate = Setting::get('reader_date');
        if ($dbDate) {
            $parsed = date_parse($dbDate);
            if ($parsed && ! empty($parsed['year'])) {
                $dbDay = (int) $parsed['day'];
                $dbMonth = (int) $parsed['month'];
                $dbYear = (int) $parsed['year'];
            }
        }

        $isValidDate = ($hari === $dbDay && $bulan === $dbMonth && $tahun === $dbYear);

        if ($isValidDate) {
            session(['is_reader_verified' => true]);

            $diary = Diary::first();
            $diaryId = $diary ? $diary->id : 1;

            return redirect()->route('diary.show', $diaryId)
                ->with('success', 'Selamat Membaca❤️');
        }

        return back()
            ->withInput()
            ->with('error', 'Tanggal verifikasi salah!Fix ga sayang.');
    }

    public function verifyAdmin(Request $request)
    {
        $request->validate([
            'password' => 'required|string',
        ]);

        $password = $request->password;
        $isValid = false;

        // 1. Cek dari database tabel users (prioritas utama standard Laravel)
        $user = User::first();
        if ($user) {
            if (Hash::check($password, $user->password) || $password === $user->password) {
                $isValid = true;
            }
        }

        // 2. Cek dari database tabel settings jika belum valid
        if (! $isValid) {
            $dbAdminPass = Setting::get('admin_password');
            if ($dbAdminPass) {
                if (Hash::check($password, $dbAdminPass) || $password === $dbAdminPass) {
                    $isValid = true;
                }
            }
        }

        // 3. Fallback ke config .env jika tabel database belum diisi
        if (! $isValid && ! $user && ! Setting::get('admin_password')) {
            $fallbackPassword = config('app.admin_password', 'admin123');
            if ($password === $fallbackPassword) {
                $isValid = true;
            }
        }

        if ($isValid) {
            session([
                'is_admin' => true,
                'is_reader_verified' => true,
            ]);

            return redirect()->route('admin.pages.index')
                ->with('success', 'Add a story.');
        }

        return back()
            ->withInput()
            ->with('admin_error', 'Password salah!');
    }

    public function logout()
    {
        session()->forget(['is_reader_verified', 'is_admin']);

        return redirect()->route('landing')
            ->with('success', 'Anda telah keluar.');
    }
}
