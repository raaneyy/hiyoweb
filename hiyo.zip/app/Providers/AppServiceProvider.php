<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        // Support otomatis jika di-deploy ke shared hosting (InfinityFree/cPanel)
        // di mana isi folder public/ dipindahkan ke ../htdocs
        if (file_exists(base_path('../htdocs')) && is_dir(base_path('../htdocs'))) {
            $this->app->usePublicPath(base_path('../htdocs'));
        }
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //
    }
}
