<?php

namespace App\Models;

use Database\Factories\PageItemFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PageItem extends Model
{
    /** @use HasFactory<PageItemFactory> */
    use HasFactory;

    protected $fillable = [
        'page_id',
        'media_type',
        'file_path',
        'caption',
        'position',
    ];

    public function page()
    {
        return $this->belongsTo(Page::class);
    }

    /**
     * Otomatis konversi prefix storage/ ke uploads/ untuk kompatibilitas data lama
     */
    public function getFilePathAttribute($value)
    {
        if (! $value) {
            return $value;
        }

        if (str_starts_with($value, 'storage/')) {
            return preg_replace('/^storage\//', 'uploads/', $value);
        }

        return $value;
    }
}
