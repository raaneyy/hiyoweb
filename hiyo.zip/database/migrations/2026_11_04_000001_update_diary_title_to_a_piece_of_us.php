<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        DB::table('diaries')
            ->whereIn('title', ['My Journal', 'My Little Space'])
            ->update(['title' => 'A Piece of Us']);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        DB::table('diaries')
            ->where('title', 'A Piece of Us')
            ->update(['title' => 'My Journal']);
    }
};

