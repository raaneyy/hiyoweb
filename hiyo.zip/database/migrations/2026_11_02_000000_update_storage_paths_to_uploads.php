<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        DB::table('page_items')
            ->where('file_path', 'like', 'storage/%')
            ->update([
                'file_path' => DB::raw("REPLACE(file_path, 'storage/', 'uploads/')"),
            ]);

        DB::table('pages')
            ->where('audio_file', 'like', 'storage/%')
            ->update([
                'audio_file' => DB::raw("REPLACE(audio_file, 'storage/', 'uploads/')"),
            ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        DB::table('page_items')
            ->where('file_path', 'like', 'uploads/%')
            ->update([
                'file_path' => DB::raw("REPLACE(file_path, 'uploads/', 'storage/')"),
            ]);

        DB::table('pages')
            ->where('audio_file', 'like', 'uploads/%')
            ->update([
                'audio_file' => DB::raw("REPLACE(audio_file, 'uploads/', 'storage/')"),
            ]);
    }
};

