<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('settings', function (Blueprint $table) {
            $table->id();
            $table->string('key')->unique();
            $table->text('value')->nullable();
            $table->timestamps();
        });

        // Seed data default validasi login
        DB::table('settings')->insert([
            ['key' => 'reader_day', 'value' => '18', 'created_at' => now(), 'updated_at' => now()],
            ['key' => 'reader_month', 'value' => '3', 'created_at' => now(), 'updated_at' => now()],
            ['key' => 'reader_year', 'value' => '2026', 'created_at' => now(), 'updated_at' => now()],
            ['key' => 'reader_clue', 'value' => 'AWAL MARET', 'created_at' => now(), 'updated_at' => now()],
            ['key' => 'admin_password', 'value' => Hash::make('admin123'), 'created_at' => now(), 'updated_at' => now()],
        ]);

        // Buat user admin default jika tabel users masih kosong
        if (Schema::hasTable('users') && DB::table('users')->count() === 0) {
            DB::table('users')->insert([
                'name' => 'Admin',
                'email' => 'admin@diary.com',
                'password' => Hash::make('admin123'),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('settings');
    }
};

